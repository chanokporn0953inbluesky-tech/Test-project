"use client";

import React, { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import NotificationDropdown from "@/components/NotificationDropdown";

interface FeedbackItem {
  id: string;
  issueId: number;
  reportCode: string;
  userName: string;
  category: string;
  categoryIcon: string;
  location: string;
  rating: number;
  isSolved: boolean;
  comment: string;
  reinspected?: boolean;
}

interface DimensionStat {
  id: number;
  title: string;
  score: number;
  percentage: number;
}

const initialDimensions: DimensionStat[] = [
  {
    id: 1,
    title: "1. ความรวดเร็วในการเข้าตรวจสอบ",
    score: 4.8,
    percentage: 96,
  },
  {
    id: 2,
    title: "2. แก้ปัญหาเสร็จทันเวลานัดหมาย",
    score: 4.6,
    percentage: 92,
  },
  { id: 3, title: "3. ความสุภาพและการประสานงาน", score: 4.9, percentage: 98 },
  {
    id: 4,
    title: "4. ความพร้อมของอุปกรณ์/มืออาชีพ",
    score: 4.7,
    percentage: 94,
  },
  { id: 5, title: "5. การอัปเดตสถานะงานต่อเนื่อง", score: 4.2, percentage: 84 },
  { id: 6, title: "6. คำชี้แจง/บันทึกผลงานชัดเจน", score: 4.5, percentage: 90 },
  {
    id: 7,
    title: "7. ความสะอาดเรียบร้อยหลังทำงาน",
    score: 3.9,
    percentage: 78,
  },
  { id: 8, title: "8. แก้ไขปัญหาได้ตรงจุด", score: 4.6, percentage: 92 },
  {
    id: 9,
    title: "9. ความมั่นใจไม่ให้เกิดปัญหาซ้ำ",
    score: 4.1,
    percentage: 82,
  },
  {
    id: 10,
    title: "10. ความพึงพอใจต่อระบบ UniCare",
    score: 4.8,
    percentage: 96,
  },
];

const mockFeedbacks: FeedbackItem[] = [
  {
    id: "1",
    issueId: 108,
    reportCode: "#REC-004",
    userName: "กิตติภูมิ ปราชญนคร",
    category: "เสียงดนตรียามวิกาล",
    categoryIcon: "🔊",
    location: "หอพักนักศึกษาชาย 3",
    rating: 5,
    isSolved: true,
    comment:
      "รปภ. เข้ามาระงับเหตุได้รวดเร็วมากครับ ภายใน 30 นาทีก็เงียบสงบ สามารถอ่านหนังสือสอบต่อได้ ขอบคุณครับ",
  },
  {
    id: "2",
    issueId: 107,
    reportCode: "#REC-012",
    userName: "นศ. สุภัทรา (สงวนนามสกุล)",
    category: "กลิ่นขยะตกค้าง",
    categoryIcon: "🗑️",
    location: "โรงอาหารกลาง",
    rating: 2,
    isSolved: false,
    comment:
      "มีการเก็บขยะไปแล้วส่วนหนึ่ง แต่น้ำขยะส่งกลิ่นเหม็นเน่ามาก ยังไม่มีการล้างพื้นจุดวางถังขยะ อยากให้ทำความสะอาดซ้ำค่ะ",
  },
  {
    id: "3",
    issueId: 106,
    reportCode: "#REC-019",
    userName: "อาจารย์ สันติสุข",
    category: "กลิ่นควันเผาหญ้า",
    categoryIcon: "🌫️",
    location: "พื้นที่ใกล้แปลงเกษตร",
    rating: 4,
    isSolved: true,
    comment:
      "เจ้าหน้าที่ประสานงานดับควันได้ดี แต่อยากให้มีมาตรการติดป้ายห้ามเผาอย่างเด็ดขาดเพิ่มเติมครับ",
  },
];

export default function AdminEvaluationPage() {
  const router = useRouter();
  const [adminName, setAdminName] = useState<string>("กิตติภูมิ ปราชญนคร");
  const [filterRating, setFilterRating] = useState<string>("all");
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>(mockFeedbacks);
  const [dimensions] = useState<DimensionStat[]>(initialDimensions);

  // States สำหรับ Modal ดูเคส และ สั่งตรวจซ้ำ
  const [selectedCase, setSelectedCase] = useState<FeedbackItem | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState<boolean>(false);
  const [isReinspectModalOpen, setIsReinspectModalOpen] =
    useState<boolean>(false);
  const [reinspectNote, setReinspectNote] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string>("");

  useEffect(() => {
    async function loadAdminUser() {
      const { data } = await supabase.auth.getUser();
      if (data?.user?.user_metadata?.full_name) {
        setAdminName(data.user.user_metadata.full_name);
      }
    }
    loadAdminUser();
  }, []);

  const handleLogout = async () => {
    if (confirm("คุณต้องการออกจากระบบหรือไม่?")) {
      await supabase.auth.signOut();
      router.push("/");
    }
  };

  // กรองตารางตามเงื่อนไข
  const filteredFeedbacks = useMemo(() => {
    return feedbacks.filter((item) => {
      if (filterRating === "5") return item.rating === 5;
      if (filterRating === "low") return item.rating <= 2;
      if (filterRating === "unsolved") return !item.isSolved;
      return true;
    });
  }, [feedbacks, filterRating]);

  // เปิด Modal ดูเคส
  const handleOpenViewModal = (item: FeedbackItem) => {
    setSelectedCase(item);
    setIsViewModalOpen(true);
  };

  // เปิด Modal สั่งตรวจซ้ำ
  const handleOpenReinspectModal = (item: FeedbackItem) => {
    setSelectedCase(item);
    setReinspectNote(
      `ผู้ร้องเรียนแจ้งว่ายังพบปัญหาเดิม ต้องการให้เข้าล้างทำความสะอาด/ระงับเหตุซ้ำอย่างเร่งด่วน`,
    );
    setIsReinspectModalOpen(true);
  };

  // ยืนยันการสั่งตรวจซ้ำ
  const handleConfirmReinspect = async () => {
    if (!selectedCase) return;

    setIsProcessing(true);
    try {
      // อัปเดตสถานะใน Supabase (ถ้ามีตาราง issue_reports)
      await supabase
        .from("issue_reports")
        .update({
          status: "In_Progress",
          description: `[สั่งตรวจซ้ำ] ${selectedCase.comment} | หมายเหตุ: ${reinspectNote}`,
        })
        .eq("issue_id", selectedCase.issueId);

      // อัปเดต state หน้าจอ
      setFeedbacks((prev) =>
        prev.map((f) =>
          f.id === selectedCase.id ? { ...f, reinspected: true } : f,
        ),
      );

      setIsReinspectModalOpen(false);
      setToastMessage(
        `ออกคำสั่งเข้าตรวจซ้ำสำหรับเคส ${selectedCase.reportCode} เรียบร้อยแล้ว`,
      );
      setTimeout(() => setToastMessage(""), 3000);
    } catch (err) {
      console.error("Error reinspecting:", err);
      alert("เกิดข้อผิดพลาดในการสั่งตรวจซ้ำ");
    } finally {
      setIsProcessing(false);
    }
  };

  const starBars = [
    {
      label: "5 ดาว",
      count: 58,
      percent: 100,
      color: "#1b5e4a",
      hoverColor: "hover:bg-[#144738]",
    },
    {
      label: "4 ดาว",
      count: 16,
      percent: 27.6,
      color: "#217972",
      hoverColor: "hover:bg-[#195e58]",
    },
    {
      label: "3 ดาว",
      count: 5,
      percent: 8.6,
      color: "#f0a42a",
      hoverColor: "hover:bg-[#d48c1a]",
    },
    {
      label: "2 ดาว",
      count: 2,
      percent: 3.4,
      color: "#f97316",
      hoverColor: "hover:bg-[#dd610d]",
    },
    {
      label: "1 ดาว",
      count: 1,
      percent: 1.7,
      color: "#ef4444",
      hoverColor: "hover:bg-[#dc2626]",
    },
  ];

  return (
    <div className="bg-[#f4f7f5] text-slate-800 antialiased min-h-screen flex font-['Prompt',sans-serif]">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-[#103e31] text-white px-5 py-3 rounded-2xl shadow-xl flex items-center space-x-2.5 border border-emerald-400/30 animate-fade-in">
          <span className="text-lg">🚨</span>
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* ==================== 1. Sidebar ==================== */}
      <aside
        className="w-64 text-white flex-shrink-0 sticky top-0 h-screen overflow-y-auto p-5 hidden md:flex flex-col justify-between border-r border-[#103e31]"
        style={{
          background:
            "linear-gradient(180deg, #2b8273 0%, #1c5e52 40%, #15453b 70%, #0f3028 100%)",
        }}
      >
        <div className="space-y-6">
          <div className="flex items-center space-x-3 pb-4 border-b border-white/15">
            <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-xl font-bold border border-white/30 shadow-xs">
              🌱
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-wider uppercase leading-none text-white drop-shadow-xs">
                UniCare
              </h1>
            </div>
          </div>

          <nav className="space-y-1.5 text-xs font-medium">
            <Link
              href="/admin/dashboard"
              className="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-emerald-100/80 hover:bg-white/10 hover:text-white transition"
            >
              <span className="text-base">🏠</span>
              <span>หน้าหลัก</span>
            </Link>

            <Link
              href="/admin/dashboard#reports"
              className="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-emerald-100/80 hover:bg-white/10 hover:text-white transition"
            >
              <span className="text-base">📢</span>
              <span>จัดการเรื่องร้องเรียน</span>
            </Link>

            <Link
              href="/admin/dashboard#map"
              className="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-emerald-100/80 hover:bg-white/10 hover:text-white transition"
            >
              <span className="text-base">🗺️</span>
              <span>แผนที่จุดเสี่ยง</span>
            </Link>

            <Link
              href="/admin/analytics"
              className="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-emerald-100/80 hover:bg-white/10 hover:text-white transition"
            >
              <span className="text-base">📊</span>
              <span>สถิติและรายงาน</span>
            </Link>

            <Link
              href="/admin/evaluation"
              className="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl bg-[#c5e8d5] text-[#0d3b2e] font-bold shadow-xs transition"
            >
              <span className="text-base">⭐</span>
              <span>ผลการประเมิน (CSAT)</span>
            </Link>

            <Link
              href="/admin/categories"
              className="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-emerald-100/80 hover:bg-white/10 hover:text-white transition"
            >
              <span className="text-base">⚙️</span>
              <span>จัดการหมวดหมู่ / SLA</span>
            </Link>

            <Link
              href="#users"
              className="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-emerald-100/80 hover:bg-white/10 hover:text-white transition"
            >
              <span className="text-base">👥</span>
              <span>จัดการบัญชีผู้ใช้</span>
            </Link>

            <button
              type="button"
              onClick={handleLogout}
              className="w-full flex items-center space-x-3 px-4 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-rose-200 hover:text-white border border-white/15 text-xs font-semibold transition mt-4 shadow-xs text-left cursor-pointer"
            >
              <span className="text-base">🚪</span>
              <span>ออกจากระบบ</span>
            </button>
          </nav>
        </div>

        <div className="bg-black/15 p-3.5 rounded-2xl border border-white/10 text-center mt-6">
          <p className="text-xs text-emerald-100/90 font-medium leading-relaxed">
            ระบบจัดการสวัสดิการและสิ่งแวดล้อม 🌱
          </p>
        </div>
      </aside>

      {/* ==================== 2. Main Content ==================== */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-slate-200/80 px-8 py-3.5 flex items-center justify-between sticky top-0 z-20 shadow-xs">
          <div>
            <h1 className="text-base font-bold text-slate-800 leading-tight">
              ระบบสรุปผลประเมินความพึงพอใจและการให้บริการ
            </h1>
            <p className="text-xs text-slate-400">
              UniCare Admin Console • วิเคราะห์คุณภาพการระงับเหตุและข้อเสนอแนะ
            </p>
          </div>

          <div className="flex items-center space-x-4">
            <NotificationDropdown />

            <div className="flex items-center space-x-2.5 bg-slate-50 border border-slate-200/80 px-3 py-1.5 rounded-full text-xs shadow-xs">
              <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-[12px]">
                👤
              </div>
              <span className="font-medium text-slate-800 hidden sm:inline-block">
                {adminName}
              </span>
              <span className="bg-[#1b5e4a] text-white text-[10px] font-bold px-2 py-0.5 rounded-full tracking-wide">
                ADMIN
              </span>
            </div>
          </div>
        </header>

        <main className="p-6 lg:p-8 space-y-6 overflow-y-auto max-w-7xl w-full">
          {/* Banner */}
          <section className="rounded-2xl bg-gradient-to-r from-[#0e4435] via-[#145946] to-[#1b6852] text-white p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
            <div className="space-y-1 max-w-xl">
              <span className="bg-emerald-400/20 text-emerald-200 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-400/30">
                Admin Quality & Assurance
              </span>
              <h2 className="text-2xl font-bold tracking-tight pt-1">
                สถิติความพึงพอใจต่อการระงับเหตุ
              </h2>
              <p className="text-xs sm:text-sm text-emerald-100/90 font-light">
                ข้อมูลประเมินผลจากนักศึกษาและบุคลากรหลังเจ้าหน้าที่เข้าตรวจสอบพื้นที่
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  alert("ดาวน์โหลดรายงานสรุปความพึงพอใจสำเร็จ (Excel)")
                }
                className="bg-white text-[#0e4435] font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs hover:bg-emerald-50 transition flex items-center gap-1.5 cursor-pointer"
              >
                <span>📥</span>
                <span>ส่งออกรายงานคำติชม (Excel)</span>
              </button>
            </div>
          </section>

          {/* 1. KPI 4 ช่อง */}
          <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <p className="text-[11px] text-slate-400 font-medium">
                  คะแนนความพึงพอใจเฉลี่ย (CSAT)
                </p>
                <h3 className="text-2xl sm:text-3xl font-bold text-slate-800 mt-0.5">
                  4.8{" "}
                  <span className="text-xs font-normal text-slate-400">
                    / 5.0
                  </span>
                </h3>
                <div className="text-[11px] text-amber-500 font-semibold mt-0.5">
                  ★★★★★ (82 ผู้ประเมิน)
                </div>
              </div>
              <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center text-2xl">
                ⭐
              </div>
            </div>

            <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <p className="text-[11px] text-slate-400 font-medium">
                  แก้ปัญหาหมดสิ้น (Resolved Rate)
                </p>
                <h3 className="text-2xl sm:text-3xl font-bold text-emerald-700 mt-0.5">
                  95.1%
                </h3>
                <span className="text-[10px] text-emerald-600 font-medium">
                  78 เคสระบุว่าเหตุการณ์สงบ
                </span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center text-2xl">
                ✅
              </div>
            </div>

            <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <p className="text-[11px] text-slate-400 font-medium">
                  อัตราการให้ข้อเสนอแนะ
                </p>
                <h3 className="text-2xl sm:text-3xl font-bold text-slate-800 mt-0.5">
                  85.4%
                </h3>
                <span className="text-[10px] text-slate-400 font-medium">
                  เทียบกับ 96 เคสที่ปิดงาน
                </span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 flex items-center justify-center text-2xl">
                📝
              </div>
            </div>

            <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <p className="text-[11px] text-slate-400 font-medium">
                  ผู้ใช้แจ้งว่า "ยังมีปัญหาอยู่"
                </p>
                <h3 className="text-2xl sm:text-3xl font-bold text-rose-600 mt-0.5">
                  4{" "}
                  <span className="text-xs font-normal text-slate-400">
                    เคส
                  </span>
                </h3>
                <span className="text-[10px] text-rose-600 font-bold">
                  ⚠️ ต้องการเข้าตรวจซ้ำ
                </span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center text-2xl">
                🚨
              </div>
            </div>
          </section>

          {/* 2. Rating Breakdown & Dimensions */}
          <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4 flex flex-col justify-between">
              <div className="border-b border-slate-100 pb-2.5">
                <h3 className="text-sm font-bold text-slate-800">
                  การแจกแจงระดับคะแนนดาว (Rating Breakdown)
                </h3>
                <p className="text-[11px] text-slate-400">
                  จำนวนการประเมินภาพรวม 1 ถึง 5 ดาว
                </p>
              </div>

              <div className="h-60 pt-4 pb-2 flex items-end justify-between gap-2.5 px-2 border-b border-slate-100">
                {starBars.map((item) => (
                  <div
                    key={item.label}
                    className="flex-1 flex flex-col items-center h-full justify-end group"
                  >
                    <span className="text-[11px] font-bold text-slate-700 mb-1.5 transition-transform group-hover:-translate-y-0.5">
                      {item.count}
                    </span>

                    <div className="w-full max-w-[44px] bg-slate-100 rounded-t-lg overflow-hidden h-[160px] flex items-end">
                      <div
                        className={`w-full rounded-t-lg transition-all duration-700 ease-out cursor-pointer ${item.hoverColor}`}
                        style={{
                          height: `${Math.max(item.percent, 4)}%`,
                          backgroundColor: item.color,
                        }}
                        title={`${item.label}: ${item.count} คน`}
                      />
                    </div>

                    <span className="text-[11px] font-medium text-slate-500 mt-2">
                      {item.label}
                    </span>
                  </div>
                ))}
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200/70 rounded-xl text-xs space-y-1">
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>ดัชนีชี้วัดความเชื่อมั่น (CSAT Index):</span>
                  <span className="font-bold text-emerald-800">96.0%</span>
                </div>
                <p className="text-[10px] text-slate-400">
                  ประเมินจากผู้ให้คะแนน 4 ดาวและ 5 ดาวรวมกัน
                </p>
              </div>
            </div>

            <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs space-y-5">
              <div className="border-b border-slate-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-slate-800">
                    ประสิทธิภาพการดำเนินงานแยกรายมิติ (10 ข้อสำคัญ)
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    ข้อมูลวิเคราะห์คะแนนเฉลี่ยรายข้อจากการประเมินของนักศึกษาและบุคลากร
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-md font-semibold">
                    ≥ 4.5 ยอดเยี่ยม
                  </span>
                  <span className="text-[10px] bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-md font-semibold">
                    &lt; 4.0 ต้องปรับปรุง
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3.5 text-xs">
                {dimensions.map((dim) => (
                  <div
                    key={dim.id}
                    className="space-y-1 bg-slate-50/70 p-2.5 rounded-xl border border-slate-100"
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-slate-700">
                        {dim.title}
                      </span>
                      <span
                        className={`font-bold ${
                          dim.score >= 4.5
                            ? "text-emerald-800"
                            : dim.score >= 4.0
                              ? "text-amber-700"
                              : "text-rose-600"
                        }`}
                      >
                        {dim.score} / 5.0 ({dim.percentage}%)
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          dim.score >= 4.5
                            ? "bg-[#1b5e4a]"
                            : dim.score >= 4.0
                              ? "bg-amber-500"
                              : "bg-rose-500"
                        }`}
                        style={{ width: `${dim.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-3 p-3.5 bg-amber-50/80 border border-amber-200/80 rounded-xl text-xs space-y-1.5">
                <div className="flex items-center space-x-1.5 text-amber-900 font-bold">
                  <span>📌 จุดที่ควรปรับปรุงเร่งด่วน:</span>
                  <span className="text-rose-700 font-semibold">
                    ข้อ 7. ความสะอาดเรียบร้อยหลังทำงาน (3.9/5.0)
                  </span>
                  <span className="text-amber-800 font-normal">และ</span>
                  <span className="text-amber-800 font-semibold">
                    ข้อ 9. มาตรการป้องกันเกิดซ้ำ (4.1/5.0)
                  </span>
                </div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  <strong>แนวทางแก้ไข:</strong>{" "}
                  กำหนดให้เจ้าหน้าที่ผู้รับผิดชอบต้องถ่ายภาพหลังทำความสะอาดพื้นที่
                  แนบในระบบก่อนปิดงาน
                  และเคสที่เป็นจุดเฝ้าระวังให้ตั้งรอบสายตรวจซ้ำอัตโนมัติภายใน 48
                  ชั่วโมง
                </p>
              </div>
            </div>
          </section>

          {/* 3. ตารางข้อเสนอแนะล่าสุด */}
          <section className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-3 gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-800">
                  รายการประเมินและข้อเสนอแนะล่าสุด
                </h3>
                <p className="text-[11px] text-slate-400">
                  ตรวจสอบความเห็นของผู้ใช้เพื่อนำไปปรับปรุงการทำงาน
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-500">กรองระดับดาว:</span>
                <select
                  value={filterRating}
                  onChange={(e) => setFilterRating(e.target.value)}
                  className="border border-slate-200 bg-[#f8faf9] rounded-lg px-2.5 py-1 text-xs text-slate-700 font-medium focus:outline-none cursor-pointer"
                >
                  <option value="all">ทั้งหมด (All Ratings)</option>
                  <option value="5">เฉพาะ 5 ดาว (ยอดเยี่ยม)</option>
                  <option value="low">1 - 2 ดาว (ต้องปรับปรุง)</option>
                  <option value="unsolved">เฉพาะเคสที่ยังไม่หมดสิ้น</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f8faf9] text-slate-500 font-semibold border-b border-slate-200/80">
                  <tr>
                    <th className="py-3 px-3">รหัสเคส / ผู้ประเมิน</th>
                    <th className="py-3 px-3">หมวดหมู่ / สถานที่</th>
                    <th className="py-3 px-3">คะแนนที่ได้</th>
                    <th className="py-3 px-3">สถานะผลลัพธ์</th>
                    <th className="py-3 px-3">ข้อเสนอแนะ / คำติชม</th>
                    <th className="py-3 px-3 text-center">จัดการ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredFeedbacks.map((row) => (
                    <tr
                      key={row.id}
                      className={`transition ${
                        !row.isSolved
                          ? "hover:bg-rose-50/40 bg-rose-50/15"
                          : "hover:bg-[#f6faf8]"
                      }`}
                    >
                      <td className="py-3.5 px-3">
                        <span className="font-bold text-slate-800 block">
                          {row.reportCode}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {row.userName}
                        </span>
                      </td>
                      <td className="py-3.5 px-3">
                        <span className="font-medium text-slate-800">
                          {row.categoryIcon} {row.category}
                        </span>
                        <span className="text-[11px] text-slate-500 block">
                          {row.location}
                        </span>
                      </td>
                      <td className="py-3.5 px-3">
                        <span className="text-amber-500 font-bold text-sm">
                          {"★".repeat(row.rating) + "☆".repeat(5 - row.rating)}
                        </span>
                        <span className="text-[10px] text-slate-400 block">
                          ({row.rating}.0 ดาว)
                        </span>
                      </td>
                      <td className="py-3.5 px-3">
                        {row.reinspected ? (
                          <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-semibold flex items-center w-max gap-1">
                            <span>🔄 ส่งตรวจซ้ำแล้ว</span>
                          </span>
                        ) : row.isSolved ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-semibold">
                            ✓ ปัญหาหมดไปแล้ว
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-semibold flex items-center w-max gap-1">
                            <span>⚠️ ยังมีปัญหาเดิม</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-3 max-w-xs text-slate-600 line-clamp-2">
                        {row.comment}
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        {!row.isSolved && !row.reinspected ? (
                          <button
                            type="button"
                            onClick={() => handleOpenReinspectModal(row)}
                            className="text-xs bg-rose-600 text-white font-bold px-3 py-1.5 rounded-lg hover:bg-rose-700 transition shadow-xs cursor-pointer active:scale-95"
                          >
                            สั่งตรวจซ้ำ
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleOpenViewModal(row)}
                            className="text-xs text-[#1b5e4a] font-bold border border-[#1b5e4a]/30 px-3 py-1.5 rounded-lg hover:bg-emerald-50 transition cursor-pointer active:scale-95"
                          >
                            ดูเคส
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </main>
      </div>

      {/* ==================== Modal: ดูเคส ==================== */}
      {isViewModalOpen && selectedCase && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <span className="text-xl">{selectedCase.categoryIcon}</span>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">
                    รายละเอียดเคส {selectedCase.reportCode}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {selectedCase.category}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsViewModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600">
              <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div>
                  <span className="text-[11px] text-slate-400 block">
                    ผู้ประเมิน:
                  </span>
                  <span className="font-semibold text-slate-800">
                    {selectedCase.userName}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">
                    สถานที่เกิดเหตุ:
                  </span>
                  <span className="font-semibold text-slate-800">
                    {selectedCase.location}
                  </span>
                </div>
                <div className="mt-2">
                  <span className="text-[11px] text-slate-400 block">
                    คะแนนความพึงพอใจ:
                  </span>
                  <span className="font-bold text-amber-500">
                    {"★".repeat(selectedCase.rating) +
                      "☆".repeat(5 - selectedCase.rating)}{" "}
                    ({selectedCase.rating}.0 ดาว)
                  </span>
                </div>
                <div className="mt-2">
                  <span className="text-[11px] text-slate-400 block">
                    สถานะผลลัพธ์:
                  </span>
                  <span className="font-semibold text-slate-800">
                    {selectedCase.isSolved
                      ? "✅ แก้ไขเรียบร้อย"
                      : "❌ ยังไม่หมดสิ้น"}
                  </span>
                </div>
              </div>

              <div>
                <span className="font-bold text-slate-700 block mb-1">
                  ความคิดเห็น / ข้อเสนอแนะ:
                </span>
                <div className="p-3 bg-[#f8faf9] rounded-xl border border-slate-200 text-slate-700 leading-relaxed">
                  "{selectedCase.comment}"
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsViewModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-semibold hover:bg-slate-50 transition cursor-pointer"
              >
                ปิดหน้าต่าง
              </button>
              <button
                type="button"
                onClick={() => router.push(`/admin/dashboard`)}
                className="px-4 py-2 rounded-xl bg-[#1b5e4a] text-white text-xs font-semibold hover:bg-[#144738] transition cursor-pointer shadow-xs"
              >
                ไปยังหน้าจัดการเคสทั้งหมด →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== Modal: สั่งตรวจซ้ำ ==================== */}
      {isReinspectModalOpen && selectedCase && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-scale-up">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center text-2xl mx-auto">
              🚨
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-slate-800">
                ยืนยันการสั่งตรวจซ้ำ ({selectedCase.reportCode})
              </h3>
              <p className="text-xs text-slate-500">
                ระบบจะส่งการแจ้งเตือนด่วนไปยังเจ้าหน้าที่ตรวจการณ์ประจำพื้นที่{" "}
                {selectedCase.location}
              </p>
            </div>

            <div className="space-y-2 text-xs">
              <label className="font-bold text-slate-700 block">
                คำสั่งปฏิบัติการ / หมายเหตุเร่งด่วน:
              </label>
              <textarea
                rows={3}
                value={reinspectNote}
                onChange={(e) => setReinspectNote(e.target.value)}
                placeholder="ระบุข้อความสั่งการไปยังเจ้าหน้าที่สายตรวจ..."
                className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-rose-500 bg-slate-50"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                disabled={isProcessing}
                onClick={() => setIsReinspectModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-xs font-semibold hover:bg-slate-50 transition cursor-pointer disabled:opacity-50"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                disabled={isProcessing}
                onClick={handleConfirmReinspect}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold transition cursor-pointer shadow-xs disabled:opacity-50 flex items-center justify-center space-x-1"
              >
                <span>
                  {isProcessing ? "กำลังส่งคำสั่ง..." : "ยืนยันสั่งตรวจซ้ำ"}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
